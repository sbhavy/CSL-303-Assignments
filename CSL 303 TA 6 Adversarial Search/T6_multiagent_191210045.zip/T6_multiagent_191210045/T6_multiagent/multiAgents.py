# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util

from game import Agent

class ReflexAgent(Agent):
    """
    A reflex agent chooses an action at each choice point by examining
    its alternatives via a state evaluation function.

    The code below is provided as a guide.  You are welcome to change
    it in any way you see fit, so long as you don't touch our method
    headers.
    """


    def getAction(self, gameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {NORTH, SOUTH, WEST, EAST, STOP}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        "Add more of your code here if you want to"

        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

        "*** YOUR CODE HERE ***"
        
        # add inverse Manhattan distance of foods
        score=0
        for i in range(len(newFood.asList())):
            temp=manhattanDistance(newPos,newFood.asList()[i])
            if(temp==0):  # if on food then add +1
                temp=1
            score+=1/temp
            
        # subtract inverse Manhattan distance of ghosts
        for i in range(len(successorGameState.getGhostPositions())):
            temp=manhattanDistance(newPos,successorGameState.getGhostPositions()[i])
            if(temp==0): # if on food then subtract 2, to stay away from ghost as much as possible
                temp=0.5
            score-=1/temp
        
        return successorGameState.getScore()+score

def scoreEvaluationFunction(currentGameState):
    """
    This default evaluation function just returns the score of the state.
    The score is the same one displayed in the Pacman GUI.

    This evaluation function is meant for use with adversarial search agents
    (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
    This class provides some common elements to all of your
    multi-agent searchers.  Any methods defined here will be available
    to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

    You *do not* need to make any changes here, but you can if you want to
    add functionality to all your adversarial search agents.  Please do not
    remove anything, however.

    Note: this is an abstract class: one that should not be instantiated.  It's
    only partially specified, and designed to be extended.  Agent (game.py)
    is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
    Your minimax agent (question 2)
    """

    def getAction(self, gameState):
        """
        Returns the minimax action from the current gameState using self.depth
        and self.evaluationFunction.

        Here are some method calls that might be useful when implementing minimax.

        gameState.getLegalActions(agentIndex):
        Returns a list of legal actions for an agent
        agentIndex=0 means Pacman, ghosts are >= 1

        gameState.generateSuccessor(agentIndex, action):
        Returns the successor game state after an agent takes an action

        gameState.getNumAgents():
        Returns the total number of agents in the game

        gameState.isWin():
        Returns whether or not the game state is a winning state

        gameState.isLose():
        Returns whether or not the game state is a losing state
        """
        "*** YOUR CODE HERE ***"
        def MiniMax(currState, currDepth, currAgent):
            
            # if PacMan wins or dies
            if(currState.isWin() or currState.isLose()):
                return self.evaluationFunction(currState)
            
            # if agent is PacMan
            if(currAgent==0):
                
                # max depth reached->evaluate position
                if(currDepth==self.depth):
                    return self.evaluationFunction(currState)
                    
                # check for its moves and implement the min-part
                else:
                    val=-99999
                    for action in currState.getLegalActions(currAgent):
                        v = MiniMax(currState.generateSuccessor(0,action), currDepth, 1)
                        val = max(v,val)
                    return val
                    
            # if agent is a ghost
            elif(currAgent!=0):
            
                # if this was the last ghost,
                # return to Pacman, and declare the depth complete
                # by traversing the next level
                val=99999
                if(currAgent == currState.getNumAgents()-1):
                
                    for action in currState.getLegalActions(currAgent):
                        v = MiniMax(currState.generateSuccessor(currAgent,action), currDepth+1, 0)
                        val = min(v,val)
                    return val        
                    
                # else do the multiagent min-part
                else:
                    
                    for action in currState.getLegalActions(currAgent):
                        v = MiniMax(currState.generateSuccessor(currAgent,action), currDepth, currAgent+1)
                        val = min(v,val)
                    return val         
                     
                     
        # record of scores and the actions that caused it
        scores=[]
        actions=[]
            
        # check all possible actions from current state
        for action in gameState.getLegalActions(0):
                
            scores.append(MiniMax(gameState.generateSuccessor(0,action), 0, 1))
            actions.append(action)          
               
        # return action that predicts max utility
        return actions[scores.index(max(scores))]
            
            

class AlphaBetaAgent(MultiAgentSearchAgent):
    """
    Your minimax agent with alpha-beta pruning (question 3)
    """
    
    def getAction(self, gameState):
        """
        Returns the minimax action using self.depth and self.evaluationFunction
        """
        "* YOUR CODE HERE *"
        MAX, MIN = 99999,-99999 
        
        def alphaBeta(currState, currDepth, currAgent,alpha,beta):
            
            # if PacMan wins or dies
            if(currState.isWin() or currState.isLose()):
                return self.evaluationFunction(currState)
            
            # if agent is PacMan
            if(currAgent==0):
                
                # max depth reached->evaluate position
                if(currDepth==self.depth):
                    return self.evaluationFunction(currState)
                    
                # check for its moves and implement the min-part
                else:
                    val=MIN
                    for action in currState.getLegalActions(currAgent):
                        v = alphaBeta(currState.generateSuccessor(0,action), currDepth, 1,alpha,beta)
                        val = max(v,val)
                        
                        # follow the algo as mentioned in the pdf file
                        if val>beta:
                            return val
                        alpha = max(alpha,val)
                    return val
                    
            # if agent is a ghost
            elif(currAgent!=0):
            
                # if this was the last ghost,
                # return to Pacman, and declare the depth complete
                # by traversing the next level
                val=MAX
                if(currAgent == currState.getNumAgents()-1):
                
                    for action in currState.getLegalActions(currAgent):
                        v = alphaBeta(currState.generateSuccessor(currAgent,action), currDepth+1, 0,alpha,beta)
                        val = min(v,val)
                        
                        # follow the algo as mentioned in the pdf file
                        if val<alpha:
                            return val
                        beta = min(beta,val)
                    return val
                         
                    
                # else do the multiagent min-part
                else:
                    
                    for action in currState.getLegalActions(currAgent):
                        v = alphaBeta(currState.generateSuccessor(currAgent,action), currDepth, currAgent+1,alpha,beta)
                        val = min(v,val)
                        
                        # follow the algo as mentioned in the pdf file
                        if val<alpha:
                            break
                        beta = min(beta,val)
                    return val      
                     
                     
        # record of scores and the actions that caused it
        scores=[]
        actions=[]
         
        # check all possible actions from current state
        alpha, beta = -99999, 99999
        for action in gameState.getLegalActions(0):
                
            val = alphaBeta(gameState.generateSuccessor(0,action), 0, 1,alpha,beta)
            scores.append(val)
            
            # update alpha for topmost node aka PacMan
            alpha = max(alpha, val)
            actions.append(action)          
               
        # return action that predicts max utility
        return actions[scores.index(max(scores))]

class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """

    def getAction(self, gameState):
        """
        Returns the expectimax action using self.depth and self.evaluationFunction

        All ghosts should be modeled as choosing uniformly at random from their
        legal moves.
        """
        "*** YOUR CODE HERE ***"
        def ExpectiMax(currState, currDepth, currAgent):
            
            # if PacMan wins or dies
            if(currState.isWin() or currState.isLose()):
                return self.evaluationFunction(currState)
            
            # if agent is PacMan
            if(currAgent==0):
                
                # max depth reached->evaluate position
                if(currDepth==self.depth):
                    return self.evaluationFunction(currState)
                    
                # check for its moves and implement the expecti-part
                else:
                    val=-99999
                    for action in currState.getLegalActions(currAgent):
                        v = ExpectiMax(currState.generateSuccessor(0,action), currDepth, 1)
                        val = max(v,val)
                    return val
                    
            # if agent is a ghost
            elif(currAgent!=0):
            
                # if this was the last ghost,
                # return to Pacman, and declare the depth complete
                # by traversing the next level
                val=[]
                if(currAgent == currState.getNumAgents()-1):
                
                    for action in currState.getLegalActions(currAgent):
                        val.append(ExpectiMax(currState.generateSuccessor(currAgent,action), currDepth+1, 0))
                    
                # else do the multiagent min-part
                else:
                    
                    for action in currState.getLegalActions(currAgent):
                        val.append(ExpectiMax(currState.generateSuccessor(currAgent,action), currDepth, currAgent+1))
                    
                return sum(val)/len(val)  # average of all moves, expected value(uniform distribution)       
                     
        # record of scores and the actions that caused it
        scores=[]
        actions=[]
            
        # check all possible actions from current state
        for action in gameState.getLegalActions(0):
                
            scores.append(ExpectiMax(gameState.generateSuccessor(0,action), 0, 1))
            actions.append(action)          
               
        # return action that predicts max utility
        return actions[scores.index(max(scores))]

def betterEvaluationFunction(currentGameState):
    """
    Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
    evaluation function (question 5).

    DESCRIPTION: <write something here so we know what you did>
    """
    
    "*** YOUR CODE HERE ***"
   
    pos = currentGameState.getPacmanPosition()
    ghost = currentGameState.getGhostStates()
    foods = currentGameState.getFood()
    food = foods.asList()
    ghosts = currentGameState.getGhostStates()
    scaredGhosts = []
    activeGhosts = []
    guide = 0

    
    for ghost in ghosts:
        if ghost.scaredTimer: scaredGhosts.append(ghost)
        else: activeGhosts.append(ghost)       
            
    for item in food:
        temp = manhattanDistance(pos,item)
       
        if temp ==2: temp = 0.65
        if temp ==1: temp = 0.3
        if temp ==0: temp = 0.01
        guide += 1/temp

    for ghost in activeGhosts:
        temp = manhattanDistance(ghost.getPosition(),pos)
        
        if temp ==2: temp = 0.3
        if temp ==1: temp = 0.30
        if temp ==0: temp = 0.01
        guide -= 1/temp
    
    for item in scaredGhosts:
        temp = manhattanDistance(pos,item.getPosition())
        if temp <=10: temp = 0.01
        guide += 1/temp
        
    
    return currentGameState.getScore() + guide

# Abbreviation
better = betterEvaluationFunction
